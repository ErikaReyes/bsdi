<?php get_header(); ?>
		<div id="banner">
			<div  id="inner-content"  class="container">
				<div id="banner" class="row">
					<div id="main" class="col-sm-12" role="main">
					<img src="http://placekitten.com/728/200">	
					</div>
				</div>
			</div>
		</div>
		<div id="menu">
			<div class="container">
				<div class="row">
					<div class="col-sm-8">
						<div class="row">
							<img src="http://placekitten.com/100/90">	
						</div>
						<div class="row">
							<ul>
								<li><a href="">link</a></li>
								<li><a href="">link</a></li>
								<li><a href="">link</a></li>
								<li><a href="">link</a></li>
								<li><a href="">link</a></li>
							</ul>
						</div>
					</div>
					<div class="col-sm-4">
						<div class="row">
							<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Repellendus, perferendis, blanditiis, ad consequatur nisi ab quos a quaerat corporis temporibus fugiat unde dolores doloribus at et odio cupiditate tempore molestias?</p>
						</div>
						<div class="row">
							<a href="">social</a>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div id="content">
			<div class="container">
				<div id="slider" class="row">
					<div class="col-sm-12">
						<img src="http://placekitten.com/1170/500">
					</div>
				</div>
				<div id="contenido" class="row">
					<div class="col-sm-8">
						<div class="row">
							<div class="col-sm-6">
								Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dignissimos, molestiae.
							</div>
							<div class="col-sm-6">
								Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aut, quam iure ipsum.
							</div>
						</div>
						<div class="row">
							Lorem ipsum dolor sit amet, consectetur adipisicing elit. Possimus, voluptate, soluta quae dolor quos odio tempore ipsam praesentium deleniti rerum eveniet esse facere blanditiis nostrum consequatur voluptas voluptatem explicabo ad.
						</div>
						<div class="row">
							Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sequi, voluptas, qui, hic ab sunt recusandae ea nam quibusdam corporis ullam facilis nostrum consectetur omnis voluptatum sapiente fuga architecto esse minima.
						</div>
					</div>
					<div class="col-sm-4">
						Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aperiam, totam, cum voluptate quae quia facere laborum optio nisi soluta vel enim dolores libero deserunt non aliquid sed necessitatibus repudiandae aut.
					</div>
				</div>
			</div>
		</div>
		<div id="footer">
			<div class="container">
				<div id="footer1" class="row">
					<div class="col-sm-2">
						<ul>
							<li>Lorem ipsum.</li>
							<li>Lorem ipsum.</li>
							<li>Lorem ipsum.</li>
							<li>Lorem ipsum.</li>
							<li>Lorem ipsum.</li>
						</ul>
					</div>
					<div class="col-sm-2">
						<ul>
							<li>Lorem ipsum.</li>
							<li>Lorem ipsum.</li>
							<li>Lorem ipsum.</li>
							<li>Lorem ipsum.</li>
							<li>Lorem ipsum.</li>
						</ul>
					</div>
					<div class="col-sm-2">
						<ul>
							<li>Lorem ipsum.</li>
							<li>Lorem ipsum.</li>
							<li>Lorem ipsum.</li>
							<li>Lorem ipsum.</li>
							<li>Lorem ipsum.</li>
						</ul>
					</div>
					<div class="col-sm-2">
						<ul>
							<li>Lorem ipsum.</li>
							<li>Lorem ipsum.</li>
							<li>Lorem ipsum.</li>
							<li>Lorem ipsum.</li>
							<li>Lorem ipsum.</li>
						</ul>
					</div>
					<div class="col-sm-4">
						<ul>
							<li>Lorem ipsum.</li>
							<li>Lorem ipsum.</li>
							<li>Lorem ipsum.</li>
							<li>Lorem ipsum.</li>
							<li>Lorem ipsum.</li>
						</ul>
					</div>
				</div>
				<div id="footer2" class="row">
					<div class="row">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Amet ipsa quibusdam veniam expedita doloribus laboriosam?</div>
					<div class="row">
						<ul>
							<li>menu</li>
							<li>menu</li>
							<li>menu</li>
							<li>menu</li>
							<li>menu</li>
						</ul>
					</div>
					<div class="row">
						Lorem ipsum dolor sit amet, consectetur adipisicing elit. Recusandae, sit animi assumenda inventore laborum officia nobis iure ut eaque veniam. Voluptatibus, ducimus, id unde quisquam illo aperiam quidem eos in expedita voluptatem quae debitis a reiciendis nesciunt itaque! Perferendis, nobis, oloribus facilis architecto mollitia praesentium sapiente saepe consequuntur similique qui.
					</div>
				</div>
			</div>
		</div>


<?php get_footer(); ?>
